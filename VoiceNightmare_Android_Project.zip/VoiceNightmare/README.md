# VOICE NIGHTMARE — Android source project

A native Android microphone-controlled survival horror game.

## Build
1. Install Android Studio (Hedgehog or newer) on a computer.
2. Open this `VoiceNightmare` folder in Android Studio.
3. Let Gradle sync. The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compile SDK 35.
4. Connect an Android phone with USB debugging enabled, or use an emulator with microphone support.
5. Press Run. Grant microphone permission when asked.

## Controls
- Whisper (quiet voice): creep toward the exit.
- Hum (steady mid-range voice): hold the creature back.
- Shout (brief loud burst): sonic blast; has a cooldown.
- Silence: lowers fear over time; useful when the creature is far away.

The app analyzes microphone volume and a basic zero-crossing pitch estimate locally. It does not record, save, or upload audio. Keep the phone's microphone unobstructed and play at a safe volume.

## Notes
- This is a playable starter game project with five escalating levels, score, lives, a mic meter, procedural horror visuals, and generated system-tone feedback.
- Microphone thresholds vary by device and room. If the meter is too sensitive, tune the thresholds in `NightmareView.tick()`.
- A computer with Android Studio is needed to build/install the APK; this source ZIP is not itself an APK.
