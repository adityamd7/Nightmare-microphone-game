package com.voicenightmare.game

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.media.AudioManager
import android.os.Bundle
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.graphics.*
import android.content.Context
import android.widget.FrameLayout
import android.widget.Toast
import kotlin.math.*
import kotlin.random.Random
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var game: NightmareView
    private var recorder: AudioRecord? = null
    private val listening = AtomicBoolean(false)
    private var micThread: Thread? = null
    private var tone: ToneGenerator? = null
    private val requestCode = 77

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.rgb(5, 6, 9)
        window.navigationBarColor = Color.rgb(5, 6, 9)
        tone = ToneGenerator(AudioManager.STREAM_MUSIC, 55)
        game = NightmareView(this) { action -> handleAction(action) }
        setContentView(FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(game, FrameLayout.LayoutParams(-1, -1))
        })
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startMic()
        } else {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestCode)
        }
    }

    private fun handleAction(action: String) {
        when (action) {
            "start_mic" -> {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startMic()
                else requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestCode)
            }
            "restart" -> game.resetGame()
            "sound" -> {
                tone?.startTone(ToneGenerator.TONE_PROP_ACK, 110)
            }
            "blast" -> tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 100)
        }
    }

    private fun startMic() {
        if (listening.get()) return
        val sampleRate = 22050
        val min = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) {
            game.setMicError("Microphone unavailable")
            return
        }
        try {
            recorder = AudioRecord(
                MediaRecorder.AudioSource.MIC, sampleRate,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                max(min, 4096)
            )
            if (recorder?.state != AudioRecord.STATE_INITIALIZED) {
                game.setMicError("Could not start microphone")
                recorder?.release()
                recorder = null
                return
            }
            recorder?.startRecording()
            listening.set(true)
            game.setMicReady(true)
            micThread = thread(name = "VoiceInput") {
                val buffer = ShortArray(2048)
                while (listening.get()) {
                    val n = try { recorder?.read(buffer, 0, buffer.size) ?: 0 } catch (_: Exception) { 0 }
                    if (n > 0) {
                        var sum = 0.0
                        var crossings = 0
                        var previous = buffer[0].toInt()
                        var peak = 0
                        for (i in 0 until n) {
                            val v = buffer[i].toInt()
                            sum += v.toDouble() * v.toDouble()
                            peak = max(peak, abs(v))
                            if ((v >= 0 && previous < 0) || (v < 0 && previous >= 0)) crossings++
                            previous = v
                        }
                        val rms = sqrt(sum / n).toFloat() / 32768f
                        val pitch = (crossings.toFloat() * 22050f / (2f * n)).coerceIn(0f, 1000f)
                        game.updateVoice(rms, peak / 32768f, pitch)
                    }
                }
            }
        } catch (_: SecurityException) {
            game.setMicError("Microphone permission denied")
        } catch (_: Exception) {
            game.setMicError("Microphone could not start")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startMic()
            else game.setMicError("Allow microphone permission to play")
        }
    }

    override fun onPause() {
        super.onPause()
        stopMic()
    }

    override fun onResume() {
        super.onResume()
        if (::game.isInitialized && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startMic()
    }

    private fun stopMic() {
        listening.set(false)
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        micThread = null
    }

    override fun onDestroy() {
        stopMic()
        tone?.release()
        super.onDestroy()
    }
}

private class NightmareView(context: Context, val action: (String) -> Unit) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val handler = Handler(Looper.getMainLooper())
    private var micReady = false
    private var micError = ""
    @Volatile private var volume = 0f
    @Volatile private var pitch = 0f
    @Volatile private var peak = 0f
    private var mode = "TITLE"
    private var level = 1
    private var score = 0
    private var lives = 3
    private var progress = 0f
    private var monster = 0.16f
    private var fear = 0f
    private var elapsed = 0L
    private var last = System.currentTimeMillis()
    private var message = "THE HOUSE HEARS EVERYTHING"
    private var messageTime = 0L
    private var whisperTime = 0f
    private var humTime = 0f
    private var shoutCooldown = 0f
    private var silenceTime = 0f
    private var particles = mutableListOf<Particle>()
    private val random = Random(System.currentTimeMillis())
    private val blood = Color.rgb(160, 20, 28)
    private val cyan = Color.rgb(90, 220, 210)
    private val white = Color.rgb(235, 235, 228)
    private val dark = Color.rgb(8, 9, 13)
    private var lastVoiceAction = 0L
    private var shake = 0f

    init { isFocusable = true; setLayerType(View.LAYER_TYPE_SOFTWARE, null); loop() }

    fun setMicReady(ready: Boolean) { post { micReady = ready; micError = ""; invalidate() } }
    fun setMicError(error: String) { post { micError = error; micReady = false; invalidate() } }

    fun updateVoice(rms: Float, peakValue: Float, pitchValue: Float) {
        volume = rms.coerceIn(0f, 1f)
        peak = peakValue.coerceIn(0f, 1f)
        pitch = pitchValue
    }

    fun resetGame() {
        mode = "TITLE"; level = 1; score = 0; lives = 3; progress = 0f
        monster = 0.16f; fear = 0f; particles.clear()
        message = "THE HOUSE HEARS EVERYTHING"
        invalidate()
    }

    private fun loop() {
        handler.postDelayed({
            val now = System.currentTimeMillis()
            val dt = ((now - last) / 1000f).coerceIn(0f, 0.05f)
            last = now
            tick(dt)
            invalidate()
            loop()
        }, 33)
    }

    private fun tick(dt: Float) {
        if (mode != "PLAY") return
        elapsed += (dt * 1000).toLong()
        shoutCooldown = max(0f, shoutCooldown - dt)
        val v = volume
        if (v < 0.012f) silenceTime += dt else silenceTime = 0f

        // Whisper to creep forward; sustained hum creates a protective ward.
        if (v in 0.012f..0.075f) {
            whisperTime += dt
            progress += dt * (0.095f + level * 0.012f)
            monster = max(0.08f, monster - dt * 0.012f)
            if (whisperTime > 0.7f) message = "WHISPER TO MOVE"
        } else whisperTime = 0f

        if (v > 0.075f && v < 0.19f && pitch in 75f..420f) {
            humTime += dt
            if (humTime > 0.55f) {
                fear = max(0f, fear - dt * 0.18f)
                monster = max(0.06f, monster - dt * 0.025f)
                message = "YOUR HUM HOLDS IT BACK"
            }
        } else humTime = 0f

        // Loud burst sends a sonic pulse. No speech is recorded or stored.
        if (v > 0.23f && shoutCooldown <= 0f) {
            shoutCooldown = 1.15f
            monster = max(0.055f, monster - 0.13f)
            fear = max(0f, fear - 0.12f)
            score += 35
            shake = 0.28f
            message = "SONIC BLAST!"
            repeat(18) {
                particles.add(Particle(width * 0.5f, height * 0.48f, random.nextFloat() * 6.28f, random.nextFloat() * 240f + 80f, 0.7f))
            }
        }

        // Silence is safe only while the monster is not too close.
        if (silenceTime > 2.2f) {
            fear = max(0f, fear - dt * 0.10f)
            if (monster > 0.78f) message = "STAY SILENT... IT IS LISTENING"
        }

        // Monster closes in when the player makes loud continuous noise or waits too long.
        monster += dt * (0.018f + level * 0.004f) + max(0f, v - 0.08f) * dt * 0.20f
        fear = (fear + dt * (0.025f + level * 0.012f)).coerceIn(0f, 1f)
        shake = max(0f, shake - dt)
        if (monster >= 0.98f) {
            lives--
            monster = 0.22f
            fear = 0.35f
            progress = max(0f, progress - 0.12f)
            message = "IT FOUND YOU!  -1 LIFE"
            shake = 0.6f
            if (lives <= 0) mode = "OVER"
        }
        if (progress >= 1f) {
            score += 250 + lives * 50
            if (level >= 5) mode = "WIN"
            else {
                level++
                progress = 0f
                monster = 0.20f
                fear = 0.15f
                message = "LEVEL $level — DEEPER INTO THE HOUSE"
            }
        }
        if (random.nextFloat() < dt * 3f) {
            particles.add(Particle(random.nextFloat() * width, height * (0.25f + random.nextFloat() * 0.6f), random.nextFloat() * 6.28f, 10f + random.nextFloat() * 25f, 1.8f))
        }
        val it = particles.iterator()
        while (it.hasNext()) {
            val a = it.next()
            a.life -= dt
            a.x += cos(a.angle) * a.speed * dt
            a.y += sin(a.angle) * a.speed * dt
            if (a.life <= 0f) it.remove()
        }
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat(); val h = height.toFloat()
        c.drawColor(dark)
        drawScene(c, w, h)
        when (mode) {
            "TITLE" -> drawTitle(c, w, h)
            "PLAY" -> drawHud(c, w, h)
            "OVER" -> drawEnd(c, w, h, false)
            "WIN" -> drawEnd(c, w, h, true)
        }
    }

    private fun drawScene(c: Canvas, w: Float, h: Float) {
        val shakeX = if (shake > 0f) random.nextFloat() * 16f - 8f else 0f
        c.save()
        c.translate(shakeX, 0f)
        val wall = Paint().apply { shader = LinearGradient(0f, 0f, 0f, h, Color.rgb(24, 24, 28), Color.rgb(3, 4, 7), Shader.TileMode.CLAMP) }
        c.drawRect(0f, 0f, w, h, wall)
        p.shader = null
        p.color = Color.rgb(34, 31, 31); p.style = Paint.Style.STROKE; p.strokeWidth = 5f
        c.drawLine(w*.08f,h*.1f,w*.08f,h*.82f,p); c.drawLine(w*.92f,h*.1f,w*.92f,h*.82f,p)
        p.color = Color.rgb(40, 35, 35); p.strokeWidth = 2f
        for (i in 0..7) c.drawLine(w*.08f,h*(.18f+i*.08f),w*.92f,h*(.18f+i*.08f),p)
        // Perspective floor
        p.style = Paint.Style.FILL
        p.color = Color.rgb(18, 17, 19)
        val floor = Path().apply { moveTo(w*.08f,h*.72f); lineTo(w*.92f,h*.72f); lineTo(w,h); lineTo(0f,h); close() }
        c.drawPath(floor,p)
        p.color = Color.rgb(55, 46, 45); p.strokeWidth = 2f; p.style = Paint.Style.STROKE
        for (i in 0..6) c.drawLine(w*.5f,h*.72f,w*(i/6f),h,p)
        // Doorway
        p.style = Paint.Style.FILL; p.color = Color.rgb(2, 2, 4)
        c.drawRoundRect(w*.34f,h*.20f,w*.66f,h*.75f,8f,8f,p)
        p.color = Color.rgb(72, 17, 23); p.style = Paint.Style.STROKE; p.strokeWidth = 5f
        c.drawRoundRect(w*.34f,h*.20f,w*.66f,h*.75f,8f,8f,p)
        // Monster silhouette approaches
        val mx = w*.5f; val my = h*(.46f + monster*.08f); val scale = .45f + monster*.95f
        c.save(); c.translate(mx,my); c.scale(scale,scale)
        p.style = Paint.Style.FILL; p.color = Color.rgb(4, 4, 6)
        c.drawOval(-w*.12f,-h*.22f,w*.12f,h*.19f,p)
        c.drawOval(-w*.19f,-h*.08f,-w*.08f,h*.25f,p); c.drawOval(w*.08f,-h*.08f,w*.19f,h*.25f,p)
        c.drawOval(-w*.10f,-h*.35f,w*.10f,-h*.12f,p)
        p.color = blood
        c.drawCircle(-w*.045f,-h*.245f,5f+monster*2,p); c.drawCircle(w*.045f,-h*.245f,5f+monster*2,p)
        p.color = Color.rgb(1,1,2); c.drawOval(-w*.045f,-h*.10f,w*.045f,h*.02f,p)
        c.restore()
        // Vignette
        p.shader = RadialGradient(w/2,h*.46f,min(w,h)*.78f,intArrayOf(Color.TRANSPARENT,0xDD000000.toInt()),null,Shader.TileMode.CLAMP)
        c.drawRect(0f,0f,w,h,p); p.shader = null
        // Particles
        p.style = Paint.Style.FILL
        for (a in particles) {
            p.color = Color.argb((a.life.coerceIn(0f,1f)*170).toInt(), 170, 190, 180)
            c.drawCircle(a.x,a.y,2.2f,p)
        }
        c.restore()
    }

    private fun drawTitle(c: Canvas, w: Float, h: Float) {
        overlay(c,w,h,0x99000000.toInt())
        text(c,"VOICE",w/2,h*.18f,52f,cyan,true,Paint.Align.CENTER)
        text(c,"NIGHTMARE",w/2,h*.25f,40f,white,true,Paint.Align.CENTER)
        text(c,"THE HOUSE HEARS EVERYTHING",w/2,h*.31f,13f,blood,true,Paint.Align.CENTER)
        text(c,"A microphone-controlled survival horror",w/2,h*.39f,14f,white,false,Paint.Align.CENTER)
        panel(c,w*.10f,h*.47f,w*.90f,h*.70f)
        text(c,"HOW TO SURVIVE",w/2,h*.51f,17f,cyan,true,Paint.Align.CENTER)
        text(c,"WHISPER  ·  CREEP FORWARD",w/2,h*.56f,13f,white,true,Paint.Align.CENTER)
        text(c,"HUM  ·  HOLD THE CREATURE BACK",w/2,h*.60f,12f,white,true,Paint.Align.CENTER)
        text(c,"SHOUT  ·  SONIC BLAST (COOLDOWN)",w/2,h*.64f,12f,white,true,Paint.Align.CENTER)
        text(c,"SILENCE  ·  LET YOUR FEAR FALL",w/2,h*.68f,12f,white,true,Paint.Align.CENTER)
        val btn = if (micReady) "TAP TO ENTER THE HOUSE" else "ENABLE MICROPHONE"
        button(c,w*.18f,h*.77f,w*.82f,h*.85f,btn)
        text(c,if (micReady) "MIC READY  •  AUDIO IS PROCESSED ON DEVICE" else (micError.ifBlank { "MIC PERMISSION REQUIRED" }),w/2,h*.91f,10f,if(micReady) cyan else blood,true,Paint.Align.CENTER)
        text(c,"HEADPHONES RECOMMENDED  •  PLAY IN A SAFE VOLUME",w/2,h*.95f,9f,white,false,Paint.Align.CENTER)
    }

    private fun drawHud(c: Canvas, w: Float, h: Float) {
        panel(c, w*.04f,h*.035f,w*.96f,h*.145f)
        text(c,"LEVEL $level / 5",w*.08f,h*.075f,14f,cyan,true)
        text(c,"SCORE  $score",w*.92f,h*.075f,14f,white,true,Paint.Align.RIGHT)
        text(c,"LIVES  ${"♥ ".repeat(lives)}",w*.08f,h*.115f,13f,blood,true)
        text(c,"EXIT PROGRESS",w*.92f,h*.115f,10f,white,true,Paint.Align.RIGHT)
        p.color = Color.rgb(45,45,50); c.drawRoundRect(w*.08f,h*.155f,w*.92f,h*.168f,8f,8f,p)
        p.color = cyan; c.drawRoundRect(w*.08f,h*.155f,w*(.08f+.84f*progress),h*.168f,8f,8f,p)
        // Voice meter
        panel(c,w*.07f,h*.82f,w*.93f,h*.94f)
        text(c,"MIC INPUT",w*.10f,h*.855f,10f,cyan,true)
        p.color = Color.rgb(50,50,55); c.drawRoundRect(w*.10f,h*.875f,w*.90f,h*.895f,8f,8f,p)
        p.color = if(volume>.23f) blood else cyan
        c.drawRoundRect(w*.10f,h*.875f,w*(.10f+.80f*volume.coerceIn(0f,1f)),h*.895f,8f,8f,p)
        val status = when {
            volume > .23f -> "LOUD: SONIC BLAST"
            volume > .075f && pitch in 75f..420f -> "HUM / VOICE WARD"
            volume > .012f -> "WHISPER: MOVING"
            else -> "SILENCE: STAY HIDDEN"
        }
        text(c,status,w/2,h*.925f,11f,white,true,Paint.Align.CENTER)
        text(c,message,w/2,h*.205f,13f,if(message.contains("FOUND")) blood else white,true,Paint.Align.CENTER)
        if (fear > .75f) text(c,"FEAR RISING",w/2,h*.24f,11f,blood,true,Paint.Align.CENTER)
        text(c,"Monster distance: ${(100-monster*100).toInt()}%",w/2,h*.78f,10f,white,false,Paint.Align.CENTER)
    }

    private fun drawEnd(c: Canvas, w: Float, h: Float, win: Boolean) {
        overlay(c,w,h,0xCC000000.toInt())
        text(c,if(win) "YOU ESCAPED" else "IT FOUND YOU",w/2,h*.35f,34f,if(win) cyan else blood,true,Paint.Align.CENTER)
        text(c,"FINAL SCORE  $score",w/2,h*.44f,20f,white,true,Paint.Align.CENTER)
        text(c,"HOUSE DEPTH  $level",w/2,h*.49f,13f,white,false,Paint.Align.CENTER)
        button(c,w*.18f,h*.60f,w*.82f,h*.69f,"PLAY AGAIN")
        text(c,"TAP TO RESTART",w/2,h*.74f,11f,cyan,true,Paint.Align.CENTER)
    }

    private fun overlay(c: Canvas,w:Float,h:Float,color:Int) { p.color=color; p.style=Paint.Style.FILL; c.drawRect(0f,0f,w,h,p) }
    private fun panel(c: Canvas,l:Float,t:Float,r:Float,b:Float) {
        p.color=0xCC0B0D12.toInt(); p.style=Paint.Style.FILL; c.drawRoundRect(l,t,r,b,16f,16f,p)
        p.color=0xAA5C646B.toInt(); p.style=Paint.Style.STROKE; p.strokeWidth=1.2f; c.drawRoundRect(l,t,r,b,16f,16f,p); p.style=Paint.Style.FILL
    }
    private fun button(c:Canvas,l:Float,t:Float,r:Float,b:Float,label:String) {
        p.color=0xDD111A20.toInt(); c.drawRoundRect(l,t,r,b,12f,12f,p)
        p.color=cyan; p.style=Paint.Style.STROKE; p.strokeWidth=2f; c.drawRoundRect(l,t,r,b,12f,12f,p); p.style=Paint.Style.FILL
        text(c,label,(l+r)/2,(t+b)/2+5f,14f,white,true,Paint.Align.CENTER)
    }
    private fun text(c:Canvas,s:String,x:Float,y:Float,size:Float,color:Int,bold:Boolean,align:Paint.Align=Paint.Align.LEFT) {
        p.shader=null; p.style=Paint.Style.FILL; p.color=color; p.textSize=size*resources.displayMetrics.density
        p.typeface=if(bold) Typeface.create("sans-serif-condensed",Typeface.BOLD) else Typeface.create("sans-serif",Typeface.NORMAL)
        p.textAlign=align; c.drawText(s,x,y,p)
    }

    override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
        if (event.action == android.view.MotionEvent.ACTION_UP) {
            val y = event.y / height.toFloat()
            when (mode) {
                "TITLE" -> {
                    if (micReady) { mode="PLAY"; last=System.currentTimeMillis(); message="WHISPER TO MOVE"; action("sound") }
                    else action("start_mic")
                }
                "OVER","WIN" -> resetGame()
            }
            invalidate()
            return true
        }
        return true
    }

    private data class Particle(var x:Float,var y:Float,val angle:Float,val speed:Float,var life:Float)
}
